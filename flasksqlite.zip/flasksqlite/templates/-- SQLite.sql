-- SQLite
INSERT INTO notes (content, lat, lng)
VALUES ('This is a note', 37.7749, -122.4194);